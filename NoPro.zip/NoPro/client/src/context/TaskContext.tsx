import { createContext, useContext, useState, useEffect, ReactNode } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { TaskState, MoodType } from '@/lib/types';
import { getPrioritizedTasks } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface TaskContextType {
  tasks: TaskState[];
  isLoading: boolean;
  error: Error | null;
  prioritizedTasks: (currentMood: MoodType) => TaskState[];
  addTask: (task: Omit<TaskState, 'id' | 'completed'>) => Promise<void>;
  updateTask: (id: number, updates: Partial<TaskState>) => Promise<void>;
  deleteTask: (id: number) => Promise<void>;
  toggleTaskCompletion: (id: number) => Promise<void>;
}

const TaskContext = createContext<TaskContextType | undefined>(undefined);

interface TaskProviderProps {
  children: ReactNode;
}

export const TaskProvider = ({ children }: TaskProviderProps) => {
  const { toast } = useToast();
  const queryClient = useQueryClient();

  // Fetch all tasks
  const { 
    data: tasks = [], 
    isLoading, 
    error 
  } = useQuery<TaskState[]>({
    queryKey: ['/api/tasks'],
  });

  // Function to get prioritized tasks based on mood
  const prioritizedTasks = (currentMood: MoodType) => {
    return getPrioritizedTasks(tasks, currentMood);
  };

  // Add a new task
  const addTaskMutation = useMutation({
    mutationFn: async (task: Omit<TaskState, 'id' | 'completed'>) => {
      const res = await apiRequest('POST', '/api/tasks', task);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task created",
        description: "Your task has been added successfully."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to add task",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Update a task
  const updateTaskMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: Partial<TaskState> }) => {
      const res = await apiRequest('PATCH', `/api/tasks/${id}`, updates);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task updated",
        description: "Your task has been updated successfully."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Delete a task
  const deleteTaskMutation = useMutation({
    mutationFn: async (id: number) => {
      const res = await apiRequest('DELETE', `/api/tasks/${id}`, undefined);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task deleted",
        description: "Your task has been deleted successfully."
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to delete task",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Toggle task completion
  const toggleTaskCompletionMutation = useMutation({
    mutationFn: async (id: number) => {
      const task = tasks.find(t => t.id === id);
      if (!task) throw new Error("Task not found");
      
      const res = await apiRequest('PATCH', `/api/tasks/${id}`, {
        completed: !task.completed
      });
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
    },
    onError: (error: Error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  // Wrapper functions
  const addTask = async (task: Omit<TaskState, 'id' | 'completed'>) => {
    await addTaskMutation.mutateAsync(task);
  };

  const updateTask = async (id: number, updates: Partial<TaskState>) => {
    await updateTaskMutation.mutateAsync({ id, updates });
  };

  const deleteTask = async (id: number) => {
    await deleteTaskMutation.mutateAsync(id);
  };

  const toggleTaskCompletion = async (id: number) => {
    await toggleTaskCompletionMutation.mutateAsync(id);
  };

  const value = {
    tasks,
    isLoading,
    error,
    prioritizedTasks,
    addTask,
    updateTask,
    deleteTask,
    toggleTaskCompletion
  };

  return <TaskContext.Provider value={value}>{children}</TaskContext.Provider>;
};

export const useTask = () => {
  const context = useContext(TaskContext);
  if (context === undefined) {
    throw new Error('useTask must be used within a TaskProvider');
  }
  return context;
};
