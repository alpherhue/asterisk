import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/ui/layout/Header';
import { BottomNavigation } from '@/components/ui/layout/BottomNavigation';
import { TaskItem } from '@/components/tasks/TaskItem';
import { FocusMode } from '@/components/focus/FocusMode';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { TaskState, MoodType } from '@/lib/types';
import { getPrioritizedTasks } from '@/lib/utils';
import { useLocation } from 'wouter';

export default function Tasks() {
  const [, setLocation] = useLocation();
  const [currentTab, setCurrentTab] = useState<"all" | "today" | "completed">("today");
  
  // Fetch latest mood
  const { data: latestMood } = useQuery<{ type: MoodType, timestamp: string }>({
    queryKey: ['/api/moods/latest'],
  });
  
  // Fetch all tasks
  const { data: tasks = [], isLoading } = useQuery<TaskState[]>({
    queryKey: ['/api/tasks'],
  });
  
  // Filter and prioritize tasks based on current tab and mood
  const getFilteredTasks = () => {
    switch (currentTab) {
      case "today":
        // Filter to show only tasks due today or with no due date
        const todayTasks = tasks.filter(task => !task.completed);
        return getPrioritizedTasks(todayTasks, latestMood?.type || "focused");
      
      case "completed":
        // Show completed tasks in reverse chronological order
        return tasks.filter(task => task.completed);
      
      case "all":
      default:
        // Show all tasks, prioritized by mood
        return getPrioritizedTasks(tasks, latestMood?.type || "focused");
    }
  };
  
  const filteredTasks = getFilteredTasks();
  
  return (
    <div id="app" className="max-w-xl mx-auto bg-white min-h-screen flex flex-col relative overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto pb-24">
        <div className="px-6 py-4">
          <div className="flex justify-between items-center mb-4">
            <h2 className="font-heading font-semibold text-xl">Tasks</h2>
            <button 
              className="text-primary-600 flex items-center text-sm font-medium"
              onClick={() => setLocation('/tasks/new')}
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-4 h-4 mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
              New Task
            </button>
          </div>
          
          <Tabs defaultValue="today" className="w-full" onValueChange={(value) => setCurrentTab(value as any)}>
            <TabsList className="grid grid-cols-3 mb-4">
              <TabsTrigger value="today">Today</TabsTrigger>
              <TabsTrigger value="all">All</TabsTrigger>
              <TabsTrigger value="completed">Completed</TabsTrigger>
            </TabsList>
            
            <TabsContent value="today" className="space-y-3">
              {isLoading ? (
                [...Array(3)].map((_, i) => (
                  <div key={i} className="p-3 bg-white border rounded-lg shadow-sm animate-pulse h-20"/>
                ))
              ) : filteredTasks.length === 0 ? (
                <div className="p-4 text-center bg-white border rounded-lg shadow-sm">
                  <p className="text-neutral-600">No tasks for today.</p>
                  <button 
                    className="mt-2 px-4 py-2 bg-primary-100 text-primary-600 rounded-md font-medium"
                    onClick={() => setLocation('/tasks/new')}
                  >
                    Add a Task
                  </button>
                </div>
              ) : (
                filteredTasks.map(task => (
                  <TaskItem key={task.id} task={task} />
                ))
              )}
            </TabsContent>
            
            <TabsContent value="all" className="space-y-3">
              {isLoading ? (
                [...Array(3)].map((_, i) => (
                  <div key={i} className="p-3 bg-white border rounded-lg shadow-sm animate-pulse h-20"/>
                ))
              ) : filteredTasks.length === 0 ? (
                <div className="p-4 text-center bg-white border rounded-lg shadow-sm">
                  <p className="text-neutral-600">No tasks available.</p>
                  <button 
                    className="mt-2 px-4 py-2 bg-primary-100 text-primary-600 rounded-md font-medium"
                    onClick={() => setLocation('/tasks/new')}
                  >
                    Add Your First Task
                  </button>
                </div>
              ) : (
                filteredTasks.map(task => (
                  <TaskItem key={task.id} task={task} />
                ))
              )}
            </TabsContent>
            
            <TabsContent value="completed" className="space-y-3">
              {isLoading ? (
                [...Array(3)].map((_, i) => (
                  <div key={i} className="p-3 bg-white border rounded-lg shadow-sm animate-pulse h-20"/>
                ))
              ) : filteredTasks.length === 0 ? (
                <div className="p-4 text-center bg-white border rounded-lg shadow-sm">
                  <p className="text-neutral-600">No completed tasks yet.</p>
                </div>
              ) : (
                filteredTasks.map(task => (
                  <TaskItem key={task.id} task={task} />
                ))
              )}
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <FocusMode />
      
      <BottomNavigation />
    </div>
  );
}
