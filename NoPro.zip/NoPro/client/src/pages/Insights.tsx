import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/ui/layout/Header';
import { BottomNavigation } from '@/components/ui/layout/BottomNavigation';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { MoodType, TaskType } from '@/lib/types';
import { format, subDays } from 'date-fns';

// Define types for insights data
interface MoodInsight {
  date: string;
  counts: Record<MoodType, number>;
}

interface TaskInsight {
  date: string;
  completed: number;
  added: number;
  byType: Record<TaskType, number>;
}

interface ProductivityInsight {
  date: string;
  focusTime: number;
  score: number;
}

export default function Insights() {
  // Fetch mood insights
  const { data: moodInsights = [] } = useQuery<MoodInsight[]>({
    queryKey: ['/api/insights/moods'],
  });

  // Fetch task insights
  const { data: taskInsights = [] } = useQuery<TaskInsight[]>({
    queryKey: ['/api/insights/tasks'],
  });

  // Fetch productivity insights
  const { data: productivityInsights = [] } = useQuery<ProductivityInsight[]>({
    queryKey: ['/api/insights/productivity'],
  });

  // Generate sample data if none available (for demonstration purposes)
  const generateMockInsights = () => {
    const mockMoodInsights: MoodInsight[] = [];
    const mockTaskInsights: TaskInsight[] = [];
    const mockProductivityInsights: ProductivityInsight[] = [];

    for (let i = 6; i >= 0; i--) {
      const date = format(subDays(new Date(), i), 'yyyy-MM-dd');
      
      mockMoodInsights.push({
        date,
        counts: {
          focused: Math.floor(Math.random() * 3),
          distracted: Math.floor(Math.random() * 2),
          tired: Math.floor(Math.random() * 2),
          stressed: Math.floor(Math.random() * 2),
          energized: Math.floor(Math.random() * 3)
        }
      });
      
      mockTaskInsights.push({
        date,
        completed: Math.floor(Math.random() * 6) + 2,
        added: Math.floor(Math.random() * 4) + 1,
        byType: {
          'deep-work': Math.floor(Math.random() * 3),
          'admin': Math.floor(Math.random() * 4),
          'creative': Math.floor(Math.random() * 2),
          'social': Math.floor(Math.random() * 2)
        }
      });
      
      mockProductivityInsights.push({
        date,
        focusTime: (Math.floor(Math.random() * 4) + 1) * 30, // in minutes
        score: Math.floor(Math.random() * 41) + 60 // score between 60-100
      });
    }
    
    return {
      mockMoodInsights,
      mockTaskInsights,
      mockProductivityInsights
    };
  };
  
  const {
    mockMoodInsights,
    mockTaskInsights,
    mockProductivityInsights
  } = generateMockInsights();
  
  // Use real data if available, otherwise use mock data
  const moods = moodInsights.length ? moodInsights : mockMoodInsights;
  const tasks = taskInsights.length ? taskInsights : mockTaskInsights;
  const productivity = productivityInsights.length ? productivityInsights : mockProductivityInsights;
  
  // Calculate some high-level stats
  const totalTasksCompleted = tasks.reduce((sum, day) => sum + day.completed, 0);
  const avgProductivityScore = Math.round(
    productivity.reduce((sum, day) => sum + day.score, 0) / productivity.length
  );
  const totalFocusTime = productivity.reduce((sum, day) => sum + day.focusTime, 0);
  const dominantMood = (() => {
    const counts: Record<MoodType, number> = {
      focused: 0,
      distracted: 0,
      tired: 0,
      stressed: 0,
      energized: 0
    };
    
    moods.forEach(day => {
      Object.entries(day.counts).forEach(([mood, count]) => {
        counts[mood as MoodType] += count;
      });
    });
    
    return Object.entries(counts).sort((a, b) => b[1] - a[1])[0][0] as MoodType;
  })();
  
  // Format mood name for display
  const formatMoodName = (mood: string) => {
    return mood.charAt(0).toUpperCase() + mood.slice(1);
  };
  
  // Format focus time in hours and minutes
  const formatFocusTime = (minutes: number) => {
    const hours = Math.floor(minutes / 60);
    const mins = minutes % 60;
    
    if (hours === 0) {
      return `${mins} minutes`;
    } else if (mins === 0) {
      return `${hours} hour${hours > 1 ? 's' : ''}`;
    } else {
      return `${hours} hour${hours > 1 ? 's' : ''} ${mins} minutes`;
    }
  };
  
  return (
    <div id="app" className="max-w-xl mx-auto bg-white min-h-screen flex flex-col relative overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto pb-24">
        <div className="px-6 py-4">
          <h2 className="font-heading font-semibold text-xl mb-4">Insights</h2>
          
          <div className="grid grid-cols-2 gap-3 mb-6">
            <Card>
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-sm font-medium text-neutral-600">Tasks Completed</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-2xl font-bold">{totalTasksCompleted}</div>
                <p className="text-xs text-neutral-500">Last 7 days</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-sm font-medium text-neutral-600">Productivity Score</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-2xl font-bold">{avgProductivityScore}</div>
                <p className="text-xs text-neutral-500">Average</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-sm font-medium text-neutral-600">Focus Time</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-2xl font-bold">{Math.round(totalFocusTime / 60)}h</div>
                <p className="text-xs text-neutral-500">Total</p>
              </CardContent>
            </Card>
            
            <Card>
              <CardHeader className="p-3 pb-1">
                <CardTitle className="text-sm font-medium text-neutral-600">Dominant Mood</CardTitle>
              </CardHeader>
              <CardContent className="p-3 pt-0">
                <div className="text-2xl font-bold">{formatMoodName(dominantMood)}</div>
                <p className="text-xs text-neutral-500">Most frequent</p>
              </CardContent>
            </Card>
          </div>
          
          <Tabs defaultValue="productivity" className="w-full">
            <TabsList className="grid grid-cols-3">
              <TabsTrigger value="productivity">Productivity</TabsTrigger>
              <TabsTrigger value="tasks">Tasks</TabsTrigger>
              <TabsTrigger value="moods">Moods</TabsTrigger>
            </TabsList>
            
            <TabsContent value="productivity" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Weekly Focus Time</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-end justify-between gap-2">
                    {productivity.map((day, i) => (
                      <div key={i} className="flex flex-col items-center flex-1">
                        <div 
                          className="w-full bg-primary-500 rounded-t-sm" 
                          style={{ height: `${(day.focusTime / 240) * 100}%` }}
                        ></div>
                        <div className="text-xs mt-2">{format(new Date(day.date), 'E')}</div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-4">
                    <h4 className="font-medium mb-2">Your Most Productive Day</h4>
                    <p className="text-sm text-neutral-600">
                      {(() => {
                        const mostProductive = [...productivity].sort((a, b) => b.score - a.score)[0];
                        return `On ${format(new Date(mostProductive.date), 'EEEE')}, you achieved a productivity score of ${mostProductive.score} with ${formatFocusTime(mostProductive.focusTime)} of focused work.`;
                      })()}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="tasks" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Task Completion</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 flex items-end justify-between gap-2">
                    {tasks.map((day, i) => (
                      <div key={i} className="flex flex-col items-center flex-1">
                        <div 
                          className="w-full bg-primary-500 rounded-t-sm" 
                          style={{ height: `${(day.completed / 10) * 100}%` }}
                        ></div>
                        <div className="text-xs mt-2">{format(new Date(day.date), 'E')}</div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="font-medium mb-2">Task Types Completed</h4>
                    <div className="space-y-2">
                      {Object.entries(
                        tasks.reduce((acc, day) => {
                          Object.entries(day.byType).forEach(([type, count]) => {
                            acc[type] = (acc[type] || 0) + count;
                          });
                          return acc;
                        }, {} as Record<string, number>)
                      ).sort((a, b) => b[1] - a[1]).map(([type, count], i) => (
                        <div key={i} className="flex items-center">
                          <div className="w-24 text-sm">{type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}</div>
                          <div className="flex-1 h-4 bg-neutral-100 rounded-full overflow-hidden">
                            <div 
                              className={
                                type === 'deep-work' ? 'bg-primary-500' :
                                type === 'admin' ? 'bg-neutral-500' :
                                type === 'creative' ? 'bg-secondary-500' : 'bg-energized-500'
                              }
                              style={{ width: `${(count / totalTasksCompleted) * 100}%`, height: '100%' }}
                            ></div>
                          </div>
                          <div className="w-10 text-right text-sm">{count}</div>
                        </div>
                      ))}
                    </div>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
            
            <TabsContent value="moods" className="mt-4">
              <Card>
                <CardHeader>
                  <CardTitle className="text-lg">Mood Patterns</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {(['energized', 'focused', 'stressed', 'tired', 'distracted'] as MoodType[]).map(mood => (
                      <div key={mood} className="flex items-center">
                        <div className="w-24 text-sm">{formatMoodName(mood)}</div>
                        <div className="flex-1">
                          <div className="flex items-center space-x-1">
                            {moods.map((day, i) => {
                              const count = day.counts[mood] || 0;
                              const bgColor = 
                                mood === 'focused' ? 'bg-calm-500' :
                                mood === 'distracted' ? 'bg-neutral-400' :
                                mood === 'tired' ? 'bg-tired-500' :
                                mood === 'stressed' ? 'bg-stressed-500' : 'bg-energized-500';
                              
                              return (
                                <div 
                                  key={i} 
                                  className={`h-6 flex-1 ${count ? bgColor : 'bg-neutral-100'} rounded-sm`}
                                  title={`${format(new Date(day.date), 'MMM d')}: ${count} times`}
                                ></div>
                              );
                            })}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                  
                  <div className="mt-6">
                    <h4 className="font-medium mb-2">Weekly Patterns</h4>
                    <p className="text-sm text-neutral-600">
                      You tend to feel most {formatMoodName(dominantMood).toLowerCase()} in the mornings between 9am-11am. 
                      Consider scheduling your most important tasks during this time.
                    </p>
                  </div>
                </CardContent>
              </Card>
            </TabsContent>
          </Tabs>
        </div>
      </main>
      
      <BottomNavigation />
    </div>
  );
}
