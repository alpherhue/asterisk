import { useState } from 'react';
import { Header } from '@/components/ui/layout/Header';
import { BottomNavigation } from '@/components/ui/layout/BottomNavigation';
import { CalendarWidget } from '@/components/calendar/CalendarWidget';
import { Calendar as CalendarComponent } from '@/components/ui/calendar';
import { FocusMode } from '@/components/focus/FocusMode';
import { Button } from '@/components/ui/button';
import { useLocation } from 'wouter';
import { format } from 'date-fns';

export default function Calendar() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date());
  const [, setLocation] = useLocation();

  const handleDateChange = (date: Date | undefined) => {
    if (date) {
      setSelectedDate(date);
    }
  };
  
  const handleAddEvent = () => {
    // In a real app, this would navigate to an event creation form
    setLocation('/calendar/new');
  };
  
  return (
    <div id="app" className="max-w-xl mx-auto bg-white min-h-screen flex flex-col relative overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto pb-24">
        <div className="px-6 py-4 bg-primary-50">
          <h2 className="font-heading font-semibold text-lg mb-4">Calendar</h2>
          <CalendarComponent
            mode="single"
            selected={selectedDate}
            onSelect={handleDateChange}
            className="border rounded-md p-3 bg-white"
          />
          
          <div className="flex justify-end mt-4">
            <Button onClick={handleAddEvent}>
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
              Add Event
            </Button>
          </div>
        </div>
        
        <CalendarWidget 
          selectedDate={selectedDate}
          onDateChange={handleDateChange}
        />
      </main>
      
      <FocusMode />
      
      <BottomNavigation />
    </div>
  );
}
