import { useState, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { useLocation, useParams } from 'wouter';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import { Header } from '@/components/ui/layout/Header';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Form,
  FormControl,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from '@/components/ui/form';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Input } from '@/components/ui/input';
import { Textarea } from '@/components/ui/textarea';
import { TaskState, TaskType } from '@/lib/types';
import { format, addDays } from 'date-fns';
import { cn } from '@/lib/utils';

// Task form validation schema
const taskSchema = z.object({
  title: z.string().min(1, "Title is required"),
  description: z.string().optional(),
  type: z.enum(["deep-work", "admin", "creative", "social"] as const),
  dueDate: z.date().optional(),
  duration: z.coerce.number().min(0).optional(),
  priority: z.coerce.number().min(0).max(10).default(5),
});

export default function TaskForm() {
  const { id } = useParams();
  const isEditing = !!id;
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch existing task if editing
  const { data: task, isLoading: isTaskLoading } = useQuery<TaskState>({
    queryKey: ['/api/tasks', id],
    enabled: isEditing,
  });
  
  // Initialize form with react-hook-form
  const form = useForm<z.infer<typeof taskSchema>>({
    resolver: zodResolver(taskSchema),
    defaultValues: {
      title: "",
      description: "",
      type: "deep-work",
      priority: 5,
    },
  });
  
  // Update form values when task data is loaded
  useEffect(() => {
    if (task) {
      form.reset({
        title: task.title,
        description: task.description || "",
        type: task.type as TaskType,
        dueDate: task.dueDate ? new Date(task.dueDate) : undefined,
        duration: task.duration,
        priority: task.priority,
      });
    }
  }, [task, form]);
  
  // Create task mutation
  const { mutate: createTask, isPending: isCreating } = useMutation({
    mutationFn: async (data: z.infer<typeof taskSchema>) => {
      const res = await apiRequest('POST', '/api/tasks', data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task created",
        description: "Your new task has been created successfully.",
      });
      setLocation('/tasks');
    },
    onError: (error) => {
      toast({
        title: "Failed to create task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Update task mutation
  const { mutate: updateTask, isPending: isUpdating } = useMutation({
    mutationFn: async (data: z.infer<typeof taskSchema>) => {
      const res = await apiRequest('PATCH', `/api/tasks/${id}`, data);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks', id] });
      toast({
        title: "Task updated",
        description: "Your task has been updated successfully.",
      });
      setLocation('/tasks');
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive",
      });
    },
  });
  
  // Handle form submission
  const onSubmit = (values: z.infer<typeof taskSchema>) => {
    if (isEditing) {
      updateTask(values);
    } else {
      createTask(values);
    }
  };
  
  const isPending = isCreating || isUpdating;
  
  return (
    <div id="app" className="max-w-xl mx-auto bg-white min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 overflow-y-auto p-6">
        <div className="flex justify-between items-center mb-6">
          <h2 className="font-heading font-semibold text-xl">
            {isEditing ? "Edit Task" : "Create New Task"}
          </h2>
          <Button variant="ghost" onClick={() => setLocation('/tasks')}>
            Cancel
          </Button>
        </div>
        
        {isEditing && isTaskLoading ? (
          <div className="animate-pulse space-y-4">
            <div className="h-10 bg-neutral-100 rounded-md"></div>
            <div className="h-24 bg-neutral-100 rounded-md"></div>
            <div className="h-10 bg-neutral-100 rounded-md"></div>
            <div className="h-10 bg-neutral-100 rounded-md"></div>
          </div>
        ) : (
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <FormField
                control={form.control}
                name="title"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Task Title</FormLabel>
                    <FormControl>
                      <Input placeholder="What do you need to do?" {...field} />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="description"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Description (Optional)</FormLabel>
                    <FormControl>
                      <Textarea 
                        placeholder="Add more details about this task" 
                        className="h-24 resize-none"
                        {...field} 
                      />
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <FormField
                control={form.control}
                name="type"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Task Type</FormLabel>
                    <Select onValueChange={field.onChange} defaultValue={field.value}>
                      <FormControl>
                        <SelectTrigger>
                          <SelectValue placeholder="Select task type" />
                        </SelectTrigger>
                      </FormControl>
                      <SelectContent>
                        <SelectItem value="deep-work">Deep Work</SelectItem>
                        <SelectItem value="admin">Admin</SelectItem>
                        <SelectItem value="creative">Creative</SelectItem>
                        <SelectItem value="social">Social</SelectItem>
                      </SelectContent>
                    </Select>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <div className="grid grid-cols-2 gap-4">
                <FormField
                  control={form.control}
                  name="dueDate"
                  render={({ field }) => (
                    <FormItem className="flex flex-col">
                      <FormLabel>Due Date (Optional)</FormLabel>
                      <Popover>
                        <PopoverTrigger asChild>
                          <FormControl>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "pl-3 text-left font-normal",
                                !field.value && "text-muted-foreground"
                              )}
                            >
                              {field.value ? (
                                format(field.value, "PPP")
                              ) : (
                                <span>Pick a date</span>
                              )}
                            </Button>
                          </FormControl>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={field.value}
                            onSelect={field.onChange}
                            initialFocus
                            disabled={(date) => date < new Date()}
                          />
                        </PopoverContent>
                      </Popover>
                      <FormMessage />
                    </FormItem>
                  )}
                />
                
                <FormField
                  control={form.control}
                  name="duration"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Duration (minutes)</FormLabel>
                      <FormControl>
                        <Input 
                          type="number" 
                          placeholder="30" 
                          {...field}
                          value={field.value || ""}
                        />
                      </FormControl>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>
              
              <FormField
                control={form.control}
                name="priority"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Priority (1-10)</FormLabel>
                    <FormControl>
                      <div className="flex items-center gap-4">
                        <Input 
                          type="range" 
                          min="1" 
                          max="10" 
                          step="1"
                          className="w-full h-2"
                          {...field}
                        />
                        <span className="w-8 text-center">{field.value}</span>
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              
              <Button 
                type="submit" 
                className="w-full" 
                disabled={isPending}
              >
                {isPending ? (
                  isEditing ? "Updating Task..." : "Creating Task..."
                ) : (
                  isEditing ? "Update Task" : "Create Task"
                )}
              </Button>
            </form>
          </Form>
        )}
      </main>
    </div>
  );
}
