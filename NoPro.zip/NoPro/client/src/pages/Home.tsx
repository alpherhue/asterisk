import { useState, useEffect } from 'react';
import { useQuery } from '@tanstack/react-query';
import { Header } from '@/components/ui/layout/Header';
import { BottomNavigation } from '@/components/ui/layout/BottomNavigation';
import { MoodCheckIn } from '@/components/mood/MoodCheckIn';
import { TaskList } from '@/components/tasks/TaskList';
import { CalendarWidget } from '@/components/calendar/CalendarWidget';
import { LoopStreaks } from '@/components/habits/LoopStreaks';
import { FocusMode } from '@/components/focus/FocusMode';
import { SmartNudge } from '@/components/smart/SmartNudge';
import { MoodState, TaskState, MoodType } from '@/lib/types';
import { generateSmartNudge } from '@/lib/utils';

export default function Home() {
  const [currentMood, setCurrentMood] = useState<MoodType>("focused");
  const [isFocusModeActive, setIsFocusModeActive] = useState(false);
  
  // Fetch latest mood
  const { data: latestMood } = useQuery<MoodState>({
    queryKey: ['/api/moods/latest'],
  });
  
  // Fetch tasks
  const { data: tasks = [] } = useQuery<TaskState[]>({
    queryKey: ['/api/tasks'],
  });
  
  // Set current mood based on latest mood data
  useEffect(() => {
    if (latestMood) {
      setCurrentMood(latestMood.type);
    }
  }, [latestMood]);
  
  // Generate smart nudge based on current mood and tasks
  const smartNudge = generateSmartNudge(currentMood, tasks);
  
  const handleMoodUpdated = (mood: MoodType) => {
    setCurrentMood(mood);
  };
  
  const handleStartTask = (taskId?: number) => {
    if (taskId) {
      setIsFocusModeActive(true);
      // In a real app we would also select the task to focus on
    }
  };
  
  const handleFocusChange = (active: boolean) => {
    setIsFocusModeActive(active);
  };
  
  return (
    <div id="app" className="max-w-xl mx-auto bg-white min-h-screen flex flex-col relative overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto pb-24">
        <MoodCheckIn 
          lastMood={latestMood} 
          onMoodUpdated={handleMoodUpdated}
        />
        
        {smartNudge && (
          <SmartNudge 
            nudge={smartNudge} 
            currentMood={currentMood}
            onAccept={handleStartTask}
          />
        )}
        
        <CalendarWidget />
        
        <TaskList currentMood={currentMood} limit={4} />
        
        <LoopStreaks limit={3} />
      </main>
      
      <FocusMode onFocusChange={handleFocusChange} />
      
      <BottomNavigation />
    </div>
  );
}
