import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { StreakState } from '@/lib/types';
import { apiRequest } from '@/lib/queryClient';
import { useLocation } from 'wouter';
import { useToast } from '@/hooks/use-toast';

interface LoopStreaksProps {
  limit?: number;
}

export function LoopStreaks({ limit }: LoopStreaksProps) {
  const [, setLocation] = useLocation();
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Fetch streaks data
  const { data: streaks = [], isLoading } = useQuery<StreakState[]>({
    queryKey: ['/api/streaks'],
  });
  
  // Limit the number of streaks displayed if requested
  const displayedStreaks = limit ? streaks.slice(0, limit) : streaks;
  
  // Mutation to mark a streak as completed for today
  const { mutate: updateStreak } = useMutation({
    mutationFn: async (streakId: number) => {
      const res = await apiRequest('PATCH', `/api/streaks/${streakId}/complete`, undefined);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/streaks'] });
      toast({
        title: "Streak updated",
        description: "Your streak has been updated for today.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update streak",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Navigate to create new streak form
  const handleAddStreak = () => {
    // This would navigate to a form to create a new streak
    toast({
      title: "Add new streak",
      description: "This feature is coming soon!",
    });
  };
  
  return (
    <section className="px-6 py-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg">Loop Streaks</h2>
        <div>
          <button 
            className="text-sm text-primary-600 font-medium"
            onClick={() => setLocation('/habits')}
          >
            Manage
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="grid grid-cols-2 gap-3">
          {[...Array(4)].map((_, i) => (
            <div key={i} className="p-3 bg-white border rounded-lg shadow-sm animate-pulse h-20"/>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-3">
          {displayedStreaks.map(streak => (
            <div 
              key={streak.id} 
              className="p-3 bg-white border rounded-lg shadow-sm flex flex-col"
              onClick={() => updateStreak(streak.id)}
            >
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-medium">{streak.title}</h4>
                <span className={`text-xs font-semibold ${
                  streak.currentStreak > 0 
                    ? "bg-primary-100 text-primary-700" 
                    : "bg-neutral-100 text-neutral-700"
                } px-2 py-0.5 rounded-full`}>
                  {streak.currentStreak > 0 
                    ? `${streak.currentStreak} day streak` 
                    : "Start today"
                  }
                </span>
              </div>
              <div className="flex space-x-1 mt-auto">
                {/* Display the last 7 days of streak progress */}
                {Array.from({ length: 7 }).map((_, index) => {
                  const date = new Date();
                  date.setDate(date.getDate() - (6 - index));
                  const dateKey = date.toISOString().split('T')[0];
                  const completed = streak.dailyProgress[dateKey] || false;
                  
                  return (
                    <div 
                      key={index} 
                      className={`h-1.5 flex-1 ${
                        completed ? 'bg-primary-500' : 'bg-neutral-200'
                      } rounded-full`}
                    />
                  );
                })}
              </div>
            </div>
          ))}
          
          {/* Add new streak button */}
          <div className="p-3 bg-white border border-dashed rounded-lg shadow-sm flex items-center justify-center">
            <button 
              className="text-primary-600 flex items-center"
              onClick={handleAddStreak}
            >
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 mr-1">
                <path strokeLinecap="round" strokeLinejoin="round" d="M12 4.5v15m7.5-7.5h-15" />
              </svg>
              <span>Add New</span>
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
