import { ReactNode } from 'react';
import { Header } from './Header';
import { BottomNavigation } from './BottomNavigation';
import { FocusMode } from '@/components/focus/FocusMode';

interface MainLayoutProps {
  children: ReactNode;
  showFocusMode?: boolean;
}

export function MainLayout({ children, showFocusMode = true }: MainLayoutProps) {
  return (
    <div id="app" className="max-w-xl mx-auto bg-white min-h-screen flex flex-col relative overflow-hidden">
      <Header />
      
      <main className="flex-1 overflow-y-auto pb-24">
        {children}
      </main>
      
      {showFocusMode && <FocusMode />}
      
      <BottomNavigation />
    </div>
  );
}
