import { useState } from 'react';
import { Drawer } from 'vaul';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';

interface FocusModeProps {
  onFocusChange?: (isActive: boolean) => void;
}

export function FocusMode({ onFocusChange }: FocusModeProps) {
  const [isActive, setIsActive] = useState(false);
  const { toast } = useToast();
  const [remainingTime, setRemainingTime] = useState(25 * 60); // 25 minutes in seconds
  const [drawerOpen, setDrawerOpen] = useState(false);
  
  const toggleFocusMode = () => {
    const newState = !isActive;
    setIsActive(newState);
    
    if (newState) {
      // Start focus mode
      setDrawerOpen(true);
      toast({
        title: "Focus Mode Activated",
        description: "Notifications have been muted. Your task is now in focus."
      });
      if (onFocusChange) {
        onFocusChange(true);
      }
    } else {
      // End focus mode
      setDrawerOpen(false);
      toast({
        title: "Focus Mode Deactivated",
        description: "Great work! Take a short break before continuing."
      });
      if (onFocusChange) {
        onFocusChange(false);
      }
    }
  };
  
  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };
  
  return (
    <>
      <div 
        className={cn(
          "fixed bottom-24 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded-full shadow-lg flex items-center z-30 cursor-pointer",
          isActive ? "bg-calm-500 text-white" : "bg-neutral-800 text-white"
        )}
        onClick={toggleFocusMode}
      >
        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5 mr-2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
        </svg>
        <span>Focus Mode</span>
      </div>
      
      <Drawer.Root open={drawerOpen && isActive} onOpenChange={setDrawerOpen}>
        <Drawer.Portal>
          <Drawer.Overlay className="fixed inset-0 bg-black/40 z-40" />
          <Drawer.Content className="bg-white flex flex-col fixed bottom-0 left-0 right-0 max-h-[85vh] z-50 rounded-t-xl">
            <div className="p-4 bg-calm-500 text-white">
              <div className="w-12 h-1.5 bg-white/20 rounded-full mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Focus Session</h3>
              <p className="text-white/80 mb-4">Stay focused on your current task.</p>
              
              <div className="flex justify-center mb-6">
                <div className="text-4xl font-mono font-bold">{formatTime(remainingTime)}</div>
              </div>
              
              <div className="flex justify-center space-x-4 mb-6">
                <button className="px-5 py-2 bg-white text-calm-500 rounded-md font-medium">
                  Pause
                </button>
                <button 
                  className="px-5 py-2 bg-calm-500 bg-opacity-20 text-white border border-white/20 rounded-md font-medium"
                  onClick={() => {
                    setIsActive(false);
                    setDrawerOpen(false);
                    if (onFocusChange) {
                      onFocusChange(false);
                    }
                  }}
                >
                  End Session
                </button>
              </div>
              
              <div className="bg-white/10 p-4 rounded-lg mb-4">
                <h4 className="font-medium mb-2">Current Task</h4>
                <p className="text-white/90 font-medium">Finalize Q3 Report</p>
                <p className="text-white/70 text-sm">Deep Work • 30 min</p>
              </div>
              
              <div className="p-4 bg-white/10 rounded-lg">
                <h4 className="font-medium mb-2">Focus Tips</h4>
                <ul className="text-sm space-y-2 text-white/80">
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Close distracting apps and notifications</span>
                  </li>
                  <li className="flex items-start">
                    <span className="mr-2">•</span>
                    <span>Take a 5-minute break after this session</span>
                  </li>
                </ul>
              </div>
            </div>
          </Drawer.Content>
        </Drawer.Portal>
      </Drawer.Root>
    </>
  );
}
