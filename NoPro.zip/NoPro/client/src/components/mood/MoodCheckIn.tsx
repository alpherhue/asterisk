import { useState, useEffect } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { MoodType, MoodColors } from '@/lib/types';
import { MoodIcons } from '@/lib/icons';
import { apiRequest } from '@/lib/queryClient';
import { format } from 'date-fns';
import { useToast } from '@/hooks/use-toast';

interface MoodCheckInProps {
  lastMood?: {
    type: MoodType;
    notes?: string;
    timestamp: string;
  };
  onMoodUpdated?: (mood: MoodType) => void;
}

export function MoodCheckIn({ lastMood, onMoodUpdated }: MoodCheckInProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [selectedMood, setSelectedMood] = useState<MoodType | null>(lastMood?.type || null);
  const [notes, setNotes] = useState(lastMood?.notes || '');
  const [lastUpdated, setLastUpdated] = useState<string | null>(lastMood?.timestamp || null);

  const moodOptions: MoodType[] = ['focused', 'distracted', 'tired', 'stressed', 'energized'];

  const moodLabels: Record<MoodType, string> = {
    focused: 'Focused',
    distracted: 'Distracted',
    tired: 'Tired',
    stressed: 'Stressed',
    energized: 'Energized'
  };

  // Mutation to update mood
  const { mutate: updateMood, isPending } = useMutation({
    mutationFn: async (data: { type: MoodType; notes: string }) => {
      const res = await apiRequest('POST', '/api/moods', data);
      return res.json();
    },
    onSuccess: (data) => {
      setLastUpdated(data.createdAt);
      if (onMoodUpdated) {
        onMoodUpdated(data.type as MoodType);
      }
      queryClient.invalidateQueries({ queryKey: ['/api/moods'] });
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] }); // Invalidate tasks as they may be reordered
      
      const moodType = data.type as MoodType;
      toast({
        title: "Mood updated",
        description: `Your mood has been set to ${moodLabels[moodType]}.`
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update mood",
        description: error.message,
        variant: "destructive"
      });
    }
  });

  const handleMoodSelection = (mood: MoodType) => {
    setSelectedMood(mood);
  };

  const handleSubmit = () => {
    if (selectedMood) {
      updateMood({ type: selectedMood, notes });
    }
  };

  // Automatically submit when mood is selected and optional notes are changed
  useEffect(() => {
    if (selectedMood) {
      const timer = setTimeout(() => {
        handleSubmit();
      }, 500);
      
      return () => clearTimeout(timer);
    }
  }, [selectedMood, notes]);

  const formatLastUpdated = (timestamp: string | null) => {
    if (!timestamp) return "Not recorded yet";
    return format(new Date(timestamp), "h:mm a");
  };

  return (
    <section className="px-6 py-4 bg-primary-50 border-b border-primary-100">
      <div className="flex items-center justify-between mb-3">
        <h2 className="font-heading font-semibold text-lg text-neutral-700">How are you feeling?</h2>
        <span className="text-xs text-neutral-500">
          Last updated: {formatLastUpdated(lastUpdated)}
        </span>
      </div>
      
      <div className="flex items-center gap-2 overflow-x-auto py-2">
        {moodOptions.map((mood) => (
          <button
            key={mood}
            onClick={() => handleMoodSelection(mood)}
            className={`mood-btn flex-shrink-0 flex flex-col items-center p-3 border rounded-xl min-w-[80px] transition-all ${
              selectedMood === mood 
                ? "bg-white border-primary-300" 
                : "hover:bg-white border-neutral-200"
            }`}
            disabled={isPending}
          >
            <div className={`w-10 h-10 rounded-full ${MoodColors[mood]} flex items-center justify-center mb-1`}>
              {MoodIcons[mood]}
            </div>
            <span className="text-sm font-medium">{moodLabels[mood]}</span>
          </button>
        ))}
      </div>
      
      <textarea
        className="mt-2 w-full p-3 rounded-lg border border-neutral-200 text-sm"
        placeholder="Add notes about how you're feeling (optional)"
        value={notes}
        onChange={(e) => setNotes(e.target.value)}
        disabled={isPending}
      />
    </section>
  );
}
