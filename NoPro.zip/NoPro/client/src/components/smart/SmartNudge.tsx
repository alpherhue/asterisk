import { useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { MoodType } from '@/lib/types';

interface SmartNudgeProps {
  nudge: {
    id: number;
    type: "focus" | "break" | "task" | "mood";
    message: string;
    detail: string;
    taskId?: number;
    actionText: string;
  };
  currentMood: MoodType;
  onAccept?: (taskId?: number) => void;
  onDismiss?: () => void;
}

export function SmartNudge({ nudge, currentMood, onAccept, onDismiss }: SmartNudgeProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  
  // Get the right background color based on mood
  const getBgColor = () => {
    const colors: Record<MoodType, string> = {
      focused: "bg-calm-500 bg-opacity-10",
      energized: "bg-energized-500 bg-opacity-10",
      tired: "bg-tired-500 bg-opacity-10",
      stressed: "bg-stressed-500 bg-opacity-10",
      distracted: "bg-neutral-400 bg-opacity-10"
    };
    
    return colors[currentMood];
  };
  
  // Get the icon color based on mood
  const getIconBgColor = () => {
    const colors: Record<MoodType, string> = {
      focused: "bg-calm-500",
      energized: "bg-energized-500",
      tired: "bg-tired-500",
      stressed: "bg-stressed-500",
      distracted: "bg-neutral-400"
    };
    
    return colors[currentMood];
  };
  
  // Mutation to accept/dismiss the nudge
  const { mutate: handleNudgeAction } = useMutation({
    mutationFn: async (accepted: boolean) => {
      const res = await apiRequest('POST', '/api/nudges/response', {
        nudgeId: nudge.id,
        accepted,
        taskId: nudge.taskId
      });
      return res.json();
    },
    onSuccess: (data, variables) => {
      if (variables) { // If accepted
        if (onAccept) {
          onAccept(nudge.taskId);
        }
        toast({
          title: "Great choice!",
          description: "Get ready to make progress on your task."
        });
      } else {
        if (onDismiss) {
          onDismiss();
        }
        toast({
          title: "No problem",
          description: "I'll suggest something else later."
        });
      }
      
      queryClient.invalidateQueries({ queryKey: ['/api/nudges'] });
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: "Failed to process your response. Please try again.",
        variant: "destructive"
      });
    }
  });
  
  return (
    <section className={`px-6 py-4 ${getBgColor()} border-b`}>
      <div className="flex items-start">
        <div className={`${getIconBgColor()} rounded-full p-2 mr-3 flex-shrink-0`}>
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="white" className="w-5 h-5">
            <path strokeLinecap="round" strokeLinejoin="round" d="M3.75 13.5l10.5-11.25L12 10.5h8.25L9.75 21.75 12 13.5H3.75z" />
          </svg>
        </div>
        <div>
          <h3 className="font-medium text-neutral-800">{nudge.message}</h3>
          <p className="text-sm text-neutral-600">{nudge.detail}</p>
          <div className="flex gap-2 mt-2">
            <button 
              className={`px-3 py-1.5 ${getIconBgColor()} text-white rounded-md text-sm`}
              onClick={() => handleNudgeAction(true)}
            >
              {nudge.actionText}
            </button>
            <button 
              className="px-3 py-1.5 bg-white border border-neutral-300 rounded-md text-sm"
              onClick={() => handleNudgeAction(false)}
            >
              Later
            </button>
          </div>
        </div>
      </div>
    </section>
  );
}
