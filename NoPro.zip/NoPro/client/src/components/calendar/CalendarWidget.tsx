import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { EventState } from '@/lib/types';
import { formatDate, formatTime } from '@/lib/utils';
import { useLocation } from 'wouter';
import { format, addDays, subDays, parseISO } from 'date-fns';

interface CalendarWidgetProps {
  selectedDate?: Date;
  onDateChange?: (date: Date) => void;
}

export function CalendarWidget({ selectedDate = new Date(), onDateChange }: CalendarWidgetProps) {
  const [currentDate, setCurrentDate] = useState<Date>(selectedDate);
  const [, setLocation] = useLocation();
  
  // Fetch events for the selected date
  const { data: events = [], isLoading } = useQuery<EventState[]>({
    queryKey: ['/api/events', format(currentDate, 'yyyy-MM-dd')],
  });
  
  const handlePreviousDay = () => {
    const newDate = subDays(currentDate, 1);
    setCurrentDate(newDate);
    if (onDateChange) {
      onDateChange(newDate);
    }
  };
  
  const handleNextDay = () => {
    const newDate = addDays(currentDate, 1);
    setCurrentDate(newDate);
    if (onDateChange) {
      onDateChange(newDate);
    }
  };
  
  return (
    <section className="px-6 py-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg">Today's Schedule</h2>
        <div className="flex gap-1">
          <button 
            className="p-1.5 rounded-md hover:bg-neutral-100"
            onClick={handlePreviousDay}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M15.75 19.5L8.25 12l7.5-7.5" />
            </svg>
          </button>
          <span className="flex items-center text-neutral-600 font-medium">
            {format(currentDate, 'EEE, MMM d')}
          </span>
          <button 
            className="p-1.5 rounded-md hover:bg-neutral-100"
            onClick={handleNextDay}
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M8.25 4.5l7.5 7.5-7.5 7.5" />
            </svg>
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="p-3 bg-white border rounded-lg shadow-sm animate-pulse h-20"/>
          ))}
        </div>
      ) : events.length === 0 ? (
        <div className="p-4 text-center bg-white border rounded-lg shadow-sm">
          <p className="text-neutral-600">No events scheduled for today.</p>
          <button 
            className="mt-2 px-4 py-2 bg-primary-100 text-primary-600 rounded-md font-medium"
            onClick={() => setLocation('/calendar')}
          >
            View Calendar
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {events.map(event => (
            <div key={event.id} className="flex items-start p-3 bg-white border rounded-lg shadow-sm">
              <div className="flex flex-col items-center mr-3">
                <span className="text-sm font-semibold">{formatTime(event.startTime)}</span>
                <span className="text-xs text-neutral-500">{formatTime(event.endTime)}</span>
              </div>
              <div className="flex-1">
                <div className="flex items-start">
                  <div className={`w-2 h-2 rounded-full ${event.color || 'bg-primary-500'} mt-1.5 mr-2`}></div>
                  <div>
                    <h4 className="font-medium text-neutral-800">{event.title}</h4>
                    {event.location && (
                      <p className="text-sm text-neutral-500">{event.location}</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </section>
  );
}
