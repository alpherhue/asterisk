import { useState } from 'react';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { TaskState, TaskColors } from '@/lib/types';
import { formatDuration } from '@/lib/utils';
import { apiRequest } from '@/lib/queryClient';
import { useToast } from '@/hooks/use-toast';
import { 
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger 
} from '@/components/ui/dropdown-menu';
import { useLocation } from 'wouter';

interface TaskItemProps {
  task: TaskState;
}

export function TaskItem({ task }: TaskItemProps) {
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const [, setLocation] = useLocation();
  const [isChecked, setIsChecked] = useState(task.completed);
  
  // Mutation to toggle task completion status
  const { mutate: toggleComplete, isPending: isToggling } = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('PATCH', `/api/tasks/${task.id}`, {
        completed: !isChecked
      });
      return res.json();
    },
    onSuccess: () => {
      setIsChecked(!isChecked);
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: !isChecked ? "Task completed" : "Task reopened",
        description: !isChecked ? "Great job!" : "You can work on it again.",
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to update task",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  // Mutation to delete a task
  const { mutate: deleteTask, isPending: isDeleting } = useMutation({
    mutationFn: async () => {
      const res = await apiRequest('DELETE', `/api/tasks/${task.id}`, undefined);
      return res.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/tasks'] });
      toast({
        title: "Task deleted",
        description: "The task has been deleted successfully."
      });
    },
    onError: (error) => {
      toast({
        title: "Failed to delete task",
        description: error.message,
        variant: "destructive"
      });
    }
  });
  
  const handleToggleComplete = () => {
    toggleComplete();
  };
  
  const handleEditTask = () => {
    setLocation(`/tasks/${task.id}`);
  };
  
  const handleDeleteTask = () => {
    deleteTask();
  };
  
  return (
    <div 
      className={`task-card p-3 bg-white border rounded-lg shadow-sm relative ${
        isChecked ? 'opacity-60' : ''
      }`} 
      data-task-type={task.type}
    >
      <div className="flex items-center">
        <input 
          type="checkbox" 
          className="w-5 h-5 border-2 border-neutral-300 rounded-md mr-3 checked:bg-primary-500"
          checked={isChecked}
          onChange={handleToggleComplete}
          disabled={isToggling || isDeleting}
        />
        <div className="flex-1">
          <h4 className={`font-medium text-neutral-800 ${isChecked ? 'line-through' : ''}`}>
            {task.title}
          </h4>
          <div className="flex items-center gap-2 mt-1">
            <span className={`text-xs py-0.5 px-2 ${TaskColors[task.type].bg} ${TaskColors[task.type].text} rounded-full`}>
              {task.type.split('-').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' ')}
            </span>
            {task.dueDate && (
              <span className="text-xs text-neutral-500">Due Today</span>
            )}
            {task.duration && (
              <span className="text-xs text-neutral-500">{formatDuration(task.duration)}</span>
            )}
          </div>
        </div>
        <div className="flex items-center ml-2">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className="p-2 text-neutral-400 hover:text-neutral-600" disabled={isDeleting}>
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth="1.5" stroke="currentColor" className="w-5 h-5">
                  <path strokeLinecap="round" strokeLinejoin="round" d="M12 6.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 12.75a.75.75 0 110-1.5.75.75 0 010 1.5zM12 18.75a.75.75 0 110-1.5.75.75 0 010 1.5z" />
                </svg>
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuItem onClick={handleEditTask}>Edit</DropdownMenuItem>
              <DropdownMenuItem 
                onClick={handleDeleteTask} 
                className="text-red-600"
              >
                Delete
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}
