import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { TaskItem } from './TaskItem';
import { TaskState, MoodType } from '@/lib/types';
import { getPrioritizedTasks } from '@/lib/utils';
import { useLocation } from 'wouter';

interface TaskListProps {
  currentMood: MoodType;
  limit?: number;
}

export function TaskList({ currentMood, limit }: TaskListProps) {
  const [, setLocation] = useLocation();
  
  // Fetch tasks from the API
  const { data: tasks = [], isLoading, error } = useQuery<TaskState[]>({
    queryKey: ['/api/tasks'],
  });
  
  // Get prioritized tasks based on current mood
  const prioritizedTasks = getPrioritizedTasks(tasks, currentMood);
  
  // Limit the number of tasks displayed if requested
  const displayedTasks = limit ? prioritizedTasks.slice(0, limit) : prioritizedTasks;
  
  return (
    <section className="px-6 py-4">
      <div className="flex justify-between items-center mb-4">
        <h2 className="font-heading font-semibold text-lg">Today's Tasks</h2>
        <div>
          <button 
            className="text-sm text-primary-600 font-medium"
            onClick={() => setLocation('/tasks')}
          >
            View All
          </button>
        </div>
      </div>
      
      {isLoading ? (
        <div className="space-y-3">
          {[...Array(3)].map((_, i) => (
            <div key={i} className="p-3 bg-white border rounded-lg shadow-sm animate-pulse h-20"/>
          ))}
        </div>
      ) : error ? (
        <div className="p-4 bg-red-50 text-red-700 rounded-lg">
          Failed to load tasks. Please try again.
        </div>
      ) : displayedTasks.length === 0 ? (
        <div className="p-4 text-center bg-white border rounded-lg shadow-sm">
          <p className="text-neutral-600">No tasks for today.</p>
          <button 
            className="mt-2 px-4 py-2 bg-primary-100 text-primary-600 rounded-md font-medium"
            onClick={() => setLocation('/tasks/new')}
          >
            Add Your First Task
          </button>
        </div>
      ) : (
        <div className="space-y-3">
          {displayedTasks.map(task => (
            <TaskItem key={task.id} task={task} />
          ))}
        </div>
      )}
    </section>
  );
}
