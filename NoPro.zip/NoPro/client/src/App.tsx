import { Switch, Route, useLocation } from "wouter";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Register from "@/pages/Register";
import Calendar from "@/pages/Calendar";
import Tasks from "@/pages/Tasks";
import Insights from "@/pages/Insights";
import TaskForm from "@/pages/TaskForm";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { TaskProvider } from "./context/TaskContext";
import { useEffect } from "react";

// AuthAwareRouter needs to be inside AuthProvider
function AuthAwareRouter() {
  const { isAuthenticated } = useAuth();
  const [location, setLocation] = useLocation();

  useEffect(() => {
    // Redirect to login if not authenticated and not on login/register pages
    if (!isAuthenticated && 
        !location.startsWith("/login") && 
        !location.startsWith("/register")) {
      setLocation("/login");
    }
  }, [isAuthenticated, location, setLocation]);

  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route path="/" component={Home} />
      <Route path="/calendar" component={Calendar} />
      <Route path="/tasks" component={Tasks} />
      <Route path="/insights" component={Insights} />
      <Route path="/tasks/new" component={TaskForm} />
      <Route path="/tasks/:id" component={TaskForm} />
      <Route component={NotFound} />
    </Switch>
  );
}

// Simple router without auth for login/registration
function SimpleRouter() {
  return (
    <Switch>
      <Route path="/login" component={Login} />
      <Route path="/register" component={Register} />
      <Route component={Login} />
    </Switch>
  );
}

function App() {
  return (
    <AuthProvider>
      <TaskProvider>
        <TooltipProvider>
          <Toaster />
          <AppRouter />
        </TooltipProvider>
      </TaskProvider>
    </AuthProvider>
  );
}

// This router checks auth state and renders appropriate routes
function AppRouter() {
  const { isAuthenticated, isLoading } = useAuth();
  
  // Show loading indicator while checking auth status
  if (isLoading) {
    return (
      <div className="h-screen flex items-center justify-center">
        <div className="animate-spin w-8 h-8 border-4 border-primary border-t-transparent rounded-full"></div>
      </div>
    );
  }
  
  // Show authenticated routes if user is logged in
  if (isAuthenticated) {
    return <AuthAwareRouter />;
  }
  
  // Show login/register routes if user is not logged in
  return <SimpleRouter />;
}

export default App;
