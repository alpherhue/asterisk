import { ClassValue, clsx } from "clsx";
import { twMerge } from "tailwind-merge";
import { format, parseISO, isToday, isYesterday, isTomorrow } from "date-fns";
import { TaskState, MoodType, TaskType } from "./types";

// Combines class names with Tailwind CSS
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// Format date with nice human readable format
export function formatDate(date: string | Date): string {
  const parsedDate = typeof date === "string" ? parseISO(date) : date;
  
  if (isToday(parsedDate)) {
    return "Today";
  } else if (isYesterday(parsedDate)) {
    return "Yesterday";
  } else if (isTomorrow(parsedDate)) {
    return "Tomorrow";
  }
  
  return format(parsedDate, "EEE, MMM d");
}

// Format time in 12-hour format
export function formatTime(time: string | Date): string {
  const parsedTime = typeof time === "string" ? parseISO(time) : time;
  return format(parsedTime, "h:mm a");
}

// Simple scoring algorithm to prioritize tasks based on mood
export function getPriorityForTaskType(type: TaskType, mood: MoodType): number {
  const priorityMatrix: Record<MoodType, Record<TaskType, number>> = {
    focused: {
      "deep-work": 4,
      "creative": 3,
      "admin": 2,
      "social": 1
    },
    energized: {
      "creative": 4,
      "deep-work": 3,
      "social": 2,
      "admin": 1
    },
    tired: {
      "admin": 4,
      "social": 3,
      "creative": 2,
      "deep-work": 1
    },
    stressed: {
      "admin": 3,
      "social": 4,
      "creative": 2,
      "deep-work": 1
    },
    distracted: {
      "admin": 4,
      "social": 2,
      "creative": 1,
      "deep-work": 3
    }
  };
  
  return priorityMatrix[mood][type];
}

// Get prioritized tasks based on current mood
export function getPrioritizedTasks(tasks: TaskState[], currentMood: MoodType): TaskState[] {
  return [...tasks].sort((a, b) => {
    // First prioritize incomplete tasks
    if (a.completed !== b.completed) {
      return a.completed ? 1 : -1;
    }
    
    // Then use the mood-based priority
    const aPriority = getPriorityForTaskType(a.type, currentMood);
    const bPriority = getPriorityForTaskType(b.type, currentMood);
    
    if (aPriority !== bPriority) {
      return bPriority - aPriority;
    }
    
    // Then by due date (if available)
    if (a.dueDate && b.dueDate) {
      return new Date(a.dueDate).getTime() - new Date(b.dueDate).getTime();
    }
    
    // Finally by user-set priority
    return b.priority - a.priority;
  });
}

// Format duration for display
export function formatDuration(minutes?: number): string {
  if (!minutes) return "";
  
  if (minutes < 60) {
    return `${minutes} min`;
  }
  
  const hours = Math.floor(minutes / 60);
  const remainingMinutes = minutes % 60;
  
  if (remainingMinutes === 0) {
    return `${hours} hr`;
  }
  
  return `${hours} hr ${remainingMinutes} min`;
}

// Generate smart nudge based on mood and tasks
export function generateSmartNudge(mood: MoodType, tasks: TaskState[]) {
  if (!tasks.length) return null;
  
  const uncompletedTasks = tasks.filter(t => !t.completed);
  if (!uncompletedTasks.length) return null;
  
  const prioritizedTasks = getPrioritizedTasks(uncompletedTasks, mood);
  const topTask = prioritizedTasks[0];
  
  const nudges = {
    focused: {
      message: "You're in your focus zone!",
      detail: `Morning is your most productive time. Want to tackle the "${topTask.title}" task now?`,
      actionText: "Start Now"
    },
    energized: {
      message: "Your energy is high!",
      detail: `Great time for creative work. Ready to work on "${topTask.title}"?`,
      actionText: "Let's Go"
    },
    tired: {
      message: "Need a recharge?",
      detail: `Taking a 10-minute break might help before working on "${topTask.title}".`,
      actionText: "Start Break"
    },
    stressed: {
      message: "Take a moment to breathe",
      detail: `Start with a small task to build momentum. How about "${topTask.title}"?`,
      actionText: "Start Small"
    },
    distracted: {
      message: "Let's regain focus",
      detail: `Try a 25-minute focused session on "${topTask.title}".`,
      actionText: "Begin Pomodoro"
    }
  };
  
  return {
    id: Date.now(),
    type: mood === "tired" || mood === "stressed" ? "break" : "task",
    message: nudges[mood].message,
    detail: nudges[mood].detail,
    taskId: topTask.id,
    actionText: nudges[mood].actionText
  };
}
