// Common types used across the application
import { ReactNode } from 'react';

export type MoodType = "focused" | "distracted" | "tired" | "stressed" | "energized";

export interface MoodState {
  type: MoodType;
  notes?: string;
  timestamp: string;
}

export type TaskType = "deep-work" | "admin" | "creative" | "social";

export interface TaskState {
  id: number;
  title: string;
  description?: string;
  type: TaskType;
  dueDate?: string;
  completed: boolean;
  duration?: number; // in minutes
  priority: number;
}

export interface EventState {
  id: number;
  title: string;
  location?: string;
  startTime: string;
  endTime: string;
  calendarId?: string;
  color?: string;
}

export interface StreakState {
  id: number;
  title: string;
  currentStreak: number;
  highestStreak: number;
  dailyProgress: Record<string, boolean>;
}

export interface UserState {
  id: number;
  username: string;
  email: string;
  name?: string;
  isAdmin?: boolean;
}

export interface SmartNudge {
  id: number;
  type: "focus" | "break" | "task" | "mood";
  message: string;
  taskId?: number;
  action?: string;
}

// Color mappings for various UI elements
export const MoodColors: Record<MoodType, string> = {
  focused: "bg-calm-500",
  distracted: "bg-neutral-400",
  tired: "bg-tired-500",
  stressed: "bg-stressed-500",
  energized: "bg-energized-500",
};

export const TaskColors: Record<TaskType, { bg: string, text: string }> = {
  "deep-work": { bg: "bg-primary-100", text: "text-primary-700" },
  "admin": { bg: "bg-neutral-100", text: "text-neutral-700" },
  "creative": { bg: "bg-secondary-100", text: "text-secondary-700" },
  "social": { bg: "bg-energized-100", text: "text-energized-700" },
};
