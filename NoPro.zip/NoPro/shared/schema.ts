import { pgTable, text, serial, integer, boolean, json, timestamp, varchar } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// User schema
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
  email: text("email").notNull().unique(),
  name: text("name"),
  isAdmin: boolean("is_admin").default(false),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
  email: true,
  name: true,
  isAdmin: true,
});

// Mood schema
export const moods = pgTable("moods", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // focused, distracted, tired, stressed, energized
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertMoodSchema = createInsertSchema(moods).pick({
  userId: true,
  type: true,
  notes: true,
});

// Task schema
export const tasks = pgTable("tasks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  description: text("description"),
  type: text("type").notNull(), // deep-work, admin, creative, social
  dueDate: timestamp("due_date"),
  completed: boolean("completed").default(false).notNull(),
  duration: integer("duration"), // in minutes
  createdAt: timestamp("created_at").defaultNow().notNull(),
  priority: integer("priority").default(0).notNull(),
});

export const insertTaskSchema = createInsertSchema(tasks).pick({
  userId: true,
  title: true,
  description: true,
  type: true,
  dueDate: true,
  duration: true,
  priority: true,
});

// Calendar event schema
export const events = pgTable("events", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  location: text("location"),
  startTime: timestamp("start_time").notNull(),
  endTime: timestamp("end_time").notNull(),
  calendarId: text("calendar_id"), // For external calendar syncing
  color: text("color"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertEventSchema = createInsertSchema(events).pick({
  userId: true,
  title: true,
  location: true,
  startTime: true,
  endTime: true,
  calendarId: true,
  color: true,
});

// Streak/Habit schema
export const streaks = pgTable("streaks", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  title: text("title").notNull(),
  currentStreak: integer("current_streak").default(0).notNull(),
  highestStreak: integer("highest_streak").default(0).notNull(),
  dailyProgress: json("daily_progress").$type<Record<string, boolean>>().default({}),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertStreakSchema = createInsertSchema(streaks).pick({
  userId: true,
  title: true,
});

// Productivity insights/patterns schema
export const insights = pgTable("insights", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull(),
  type: text("type").notNull(), // focus-time, productivity-score, mood-patterns, etc.
  data: json("data").$type<Record<string, any>>(),
  date: timestamp("date").defaultNow().notNull(),
});

export const insertInsightSchema = createInsertSchema(insights).pick({
  userId: true,
  type: true,
  data: true,
});

// Define types for use in the application
export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;

export type Mood = typeof moods.$inferSelect;
export type InsertMood = z.infer<typeof insertMoodSchema>;

export type Task = typeof tasks.$inferSelect;
export type InsertTask = z.infer<typeof insertTaskSchema>;

export type Event = typeof events.$inferSelect;
export type InsertEvent = z.infer<typeof insertEventSchema>;

export type Streak = typeof streaks.$inferSelect;
export type InsertStreak = z.infer<typeof insertStreakSchema>;

export type Insight = typeof insights.$inferSelect;
export type InsertInsight = z.infer<typeof insertInsightSchema>;
