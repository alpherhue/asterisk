import { 
  users, type User, type InsertUser, 
  moods, type Mood, type InsertMood,
  tasks, type Task, type InsertTask,
  events, type Event, type InsertEvent,
  streaks, type Streak, type InsertStreak,
  insights, type Insight, type InsertInsight
} from "@shared/schema";

// Interface for all storage operations
import session from "express-session";

export interface IStorage {
  // Session store for authentication
  sessionStore: session.Store;
  
  // User methods
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  // Mood methods
  getMoods(userId: number): Promise<Mood[]>;
  getLatestMood(userId: number): Promise<Mood | undefined>;
  createMood(mood: InsertMood): Promise<Mood>;
  
  // Task methods
  getTasks(userId: number): Promise<Task[]>;
  getTask(id: number): Promise<Task | undefined>;
  createTask(task: InsertTask): Promise<Task>;
  updateTask(id: number, updates: Partial<Task>): Promise<Task>;
  deleteTask(id: number): Promise<boolean>;
  
  // Event methods
  getEvents(userId: number, date?: string): Promise<Event[]>;
  getEvent(id: number): Promise<Event | undefined>;
  createEvent(event: InsertEvent): Promise<Event>;
  updateEvent(id: number, updates: Partial<Event>): Promise<Event>;
  deleteEvent(id: number): Promise<boolean>;
  
  // Streak methods
  getStreaks(userId: number): Promise<Streak[]>;
  getStreak(id: number): Promise<Streak | undefined>;
  createStreak(streak: InsertStreak): Promise<Streak>;
  updateStreak(id: number, updates: Partial<Streak>): Promise<Streak>;
  completeStreakForToday(id: number): Promise<Streak>;
  deleteStreak(id: number): Promise<boolean>;
  
  // Insight methods
  getInsights(userId: number, type: string): Promise<Insight[]>;
  createInsight(insight: InsertInsight): Promise<Insight>;
}

import createMemoryStore from "memorystore";

const MemoryStore = createMemoryStore(session);

export class MemStorage implements IStorage {
  sessionStore: session.Store;
  
  private users: Map<number, User>;
  private moods: Map<number, Mood>;
  private tasks: Map<number, Task>;
  private events: Map<number, Event>;
  private streaks: Map<number, Streak>;
  private insights: Map<number, Insight>;
  
  private userIdCounter: number;
  private moodIdCounter: number;
  private taskIdCounter: number;
  private eventIdCounter: number;
  private streakIdCounter: number;
  private insightIdCounter: number;

  constructor() {
    this.sessionStore = new MemoryStore({
      checkPeriod: 86400000, // prune expired entries every 24h
    });
    
    this.users = new Map();
    this.moods = new Map();
    this.tasks = new Map();
    this.events = new Map();
    this.streaks = new Map();
    this.insights = new Map();
    
    this.userIdCounter = 1;
    this.moodIdCounter = 1;
    this.taskIdCounter = 1;
    this.eventIdCounter = 1;
    this.streakIdCounter = 1;
    this.insightIdCounter = 1;
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }
  
  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.email === email,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.userIdCounter++;
    const createdAt = new Date();
    const user: User = { 
      ...insertUser, 
      id, 
      createdAt,
      isAdmin: insertUser.isAdmin || false 
    };
    this.users.set(id, user);
    return user;
  }

  // Mood methods
  async getMoods(userId: number): Promise<Mood[]> {
    return Array.from(this.moods.values())
      .filter(mood => mood.userId === userId)
      .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  }

  async getLatestMood(userId: number): Promise<Mood | undefined> {
    const userMoods = await this.getMoods(userId);
    return userMoods.length > 0 ? userMoods[0] : undefined;
  }

  async createMood(insertMood: InsertMood): Promise<Mood> {
    const id = this.moodIdCounter++;
    const createdAt = new Date();
    const mood: Mood = { ...insertMood, id, createdAt };
    this.moods.set(id, mood);
    return mood;
  }

  // Task methods
  async getTasks(userId: number): Promise<Task[]> {
    return Array.from(this.tasks.values())
      .filter(task => task.userId === userId)
      .sort((a, b) => {
        // Sort by completion status first
        if (a.completed !== b.completed) {
          return a.completed ? 1 : -1;
        }
        // Then by priority (higher priority first)
        if (a.priority !== b.priority) {
          return b.priority - a.priority;
        }
        // Finally by creation date (newer first)
        return new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime();
      });
  }

  async getTask(id: number): Promise<Task | undefined> {
    return this.tasks.get(id);
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const id = this.taskIdCounter++;
    const createdAt = new Date();
    const task: Task = { 
      ...insertTask, 
      id, 
      completed: false, 
      createdAt 
    };
    this.tasks.set(id, task);
    return task;
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task> {
    const task = this.tasks.get(id);
    if (!task) {
      throw new Error(`Task with id ${id} not found`);
    }
    
    const updatedTask = { ...task, ...updates };
    this.tasks.set(id, updatedTask);
    return updatedTask;
  }

  async deleteTask(id: number): Promise<boolean> {
    return this.tasks.delete(id);
  }

  // Event methods
  async getEvents(userId: number, date?: string): Promise<Event[]> {
    let events = Array.from(this.events.values())
      .filter(event => event.userId === userId);
    
    if (date) {
      const dateStart = new Date(date);
      dateStart.setHours(0, 0, 0, 0);
      
      const dateEnd = new Date(date);
      dateEnd.setHours(23, 59, 59, 999);
      
      events = events.filter(event => {
        const eventStart = new Date(event.startTime);
        return eventStart >= dateStart && eventStart <= dateEnd;
      });
    }
    
    return events.sort((a, b) => 
      new Date(a.startTime).getTime() - new Date(b.startTime).getTime()
    );
  }

  async getEvent(id: number): Promise<Event | undefined> {
    return this.events.get(id);
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const id = this.eventIdCounter++;
    const createdAt = new Date();
    const event: Event = { ...insertEvent, id, createdAt };
    this.events.set(id, event);
    return event;
  }

  async updateEvent(id: number, updates: Partial<Event>): Promise<Event> {
    const event = this.events.get(id);
    if (!event) {
      throw new Error(`Event with id ${id} not found`);
    }
    
    const updatedEvent = { ...event, ...updates };
    this.events.set(id, updatedEvent);
    return updatedEvent;
  }

  async deleteEvent(id: number): Promise<boolean> {
    return this.events.delete(id);
  }

  // Streak methods
  async getStreaks(userId: number): Promise<Streak[]> {
    return Array.from(this.streaks.values())
      .filter(streak => streak.userId === userId);
  }

  async getStreak(id: number): Promise<Streak | undefined> {
    return this.streaks.get(id);
  }

  async createStreak(insertStreak: InsertStreak): Promise<Streak> {
    const id = this.streakIdCounter++;
    const createdAt = new Date();
    const streak: Streak = { 
      ...insertStreak,
      id,
      currentStreak: 0,
      highestStreak: 0,
      dailyProgress: {},
      createdAt
    };
    this.streaks.set(id, streak);
    return streak;
  }

  async updateStreak(id: number, updates: Partial<Streak>): Promise<Streak> {
    const streak = this.streaks.get(id);
    if (!streak) {
      throw new Error(`Streak with id ${id} not found`);
    }
    
    const updatedStreak = { ...streak, ...updates };
    this.streaks.set(id, updatedStreak);
    return updatedStreak;
  }

  async completeStreakForToday(id: number): Promise<Streak> {
    const streak = this.streaks.get(id);
    if (!streak) {
      throw new Error(`Streak with id ${id} not found`);
    }
    
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    
    const dailyProgress = { ...streak.dailyProgress };
    dailyProgress[today] = true;
    
    // Check if yesterday was completed to determine streak
    let currentStreak = dailyProgress[yesterday] ? streak.currentStreak + 1 : 1;
    const highestStreak = Math.max(currentStreak, streak.highestStreak);
    
    const updatedStreak = { 
      ...streak, 
      dailyProgress, 
      currentStreak,
      highestStreak
    };
    
    this.streaks.set(id, updatedStreak);
    return updatedStreak;
  }

  async deleteStreak(id: number): Promise<boolean> {
    return this.streaks.delete(id);
  }

  // Insight methods
  async getInsights(userId: number, type: string): Promise<Insight[]> {
    return Array.from(this.insights.values())
      .filter(insight => insight.userId === userId && insight.type === type)
      .sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
  }

  async createInsight(insertInsight: InsertInsight): Promise<Insight> {
    const id = this.insightIdCounter++;
    const date = new Date();
    const insight: Insight = { 
      ...insertInsight, 
      id,
      date,
      data: insertInsight.data || null
    };
    this.insights.set(id, insight);
    return insight;
  }
}

// Import the DatabaseStorage class
import { DatabaseStorage } from "./storage-db";

// Use DatabaseStorage instead of MemStorage for persistent storage
export const storage = new DatabaseStorage();
