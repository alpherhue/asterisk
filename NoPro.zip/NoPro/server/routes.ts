import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { Auth } from "./auth";
import { z } from "zod";
import { 
  insertMoodSchema, 
  insertTaskSchema, 
  insertEventSchema, 
  insertStreakSchema,
  insertInsightSchema 
} from "@shared/schema";
import { fromZodError } from "zod-validation-error";
import session from "express-session";
export async function registerRoutes(app: Express): Promise<Server> {
  // Setup express-session with PostgreSQL session store
  app.use(
    session({
      secret: process.env.SESSION_SECRET || "loop-secret-key",
      resave: false,
      saveUninitialized: false,
      store: storage.sessionStore,
      cookie: {
        secure: process.env.NODE_ENV === "production",
        httpOnly: true,
        maxAge: 24 * 60 * 60 * 1000 // 24 hours
      }
    })
  );

  // Initialize auth
  const auth = new Auth(storage);

  // Auth routes
  app.post("/api/auth/register", auth.register);
  app.post("/api/auth/login", auth.login);
  app.get("/api/auth/me", auth.me);
  app.post("/api/auth/logout", auth.logout);

  // Mood routes
  app.get("/api/moods", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const moods = await storage.getMoods(userId);
      res.json(moods);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/moods/latest", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const mood = await storage.getLatestMood(userId);
      
      if (!mood) {
        return res.status(404).json({ message: "No mood records found" });
      }
      
      res.json(mood);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/moods", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const moodData = { ...req.body, userId };
      
      // Validate
      const validatedData = insertMoodSchema.parse(moodData);
      
      // Create mood
      const mood = await storage.createMood(validatedData);
      res.status(201).json(mood);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Task routes
  app.get("/api/tasks", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const tasks = await storage.getTasks(userId);
      res.json(tasks);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/tasks/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Ensure user can only access their own tasks
      if (task.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(task);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/tasks", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const taskData = { ...req.body, userId };
      
      // Validate
      const validatedData = insertTaskSchema.parse(taskData);
      
      // Create task
      const task = await storage.createTask(validatedData);
      res.status(201).json(task);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/tasks/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Ensure user can only update their own tasks
      if (task.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Update task
      const updatedTask = await storage.updateTask(taskId, req.body);
      res.json(updatedTask);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/tasks/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const taskId = parseInt(req.params.id);
      const task = await storage.getTask(taskId);
      
      if (!task) {
        return res.status(404).json({ message: "Task not found" });
      }
      
      // Ensure user can only delete their own tasks
      if (task.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Delete task
      await storage.deleteTask(taskId);
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Calendar Event routes
  app.get("/api/events", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const date = req.query.date as string | undefined;
      const events = await storage.getEvents(userId, date);
      res.json(events);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/events/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Ensure user can only access their own events
      if (event.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(event);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/events", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const eventData = { ...req.body, userId };
      
      // Validate
      const validatedData = insertEventSchema.parse(eventData);
      
      // Create event
      const event = await storage.createEvent(validatedData);
      res.status(201).json(event);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/events/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Ensure user can only update their own events
      if (event.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Update event
      const updatedEvent = await storage.updateEvent(eventId, req.body);
      res.json(updatedEvent);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/events/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const eventId = parseInt(req.params.id);
      const event = await storage.getEvent(eventId);
      
      if (!event) {
        return res.status(404).json({ message: "Event not found" });
      }
      
      // Ensure user can only delete their own events
      if (event.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Delete event
      await storage.deleteEvent(eventId);
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Streak routes
  app.get("/api/streaks", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const streaks = await storage.getStreaks(userId);
      res.json(streaks);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.get("/api/streaks/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const streakId = parseInt(req.params.id);
      const streak = await storage.getStreak(streakId);
      
      if (!streak) {
        return res.status(404).json({ message: "Streak not found" });
      }
      
      // Ensure user can only access their own streaks
      if (streak.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      res.json(streak);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/streaks", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const streakData = { ...req.body, userId };
      
      // Validate
      const validatedData = insertStreakSchema.parse(streakData);
      
      // Create streak
      const streak = await storage.createStreak(validatedData);
      res.status(201).json(streak);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/streaks/:id/complete", auth.isAuthenticated, async (req, res) => {
    try {
      const streakId = parseInt(req.params.id);
      const streak = await storage.getStreak(streakId);
      
      if (!streak) {
        return res.status(404).json({ message: "Streak not found" });
      }
      
      // Ensure user can only update their own streaks
      if (streak.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Complete streak for today
      const updatedStreak = await storage.completeStreakForToday(streakId);
      res.json(updatedStreak);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.patch("/api/streaks/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const streakId = parseInt(req.params.id);
      const streak = await storage.getStreak(streakId);
      
      if (!streak) {
        return res.status(404).json({ message: "Streak not found" });
      }
      
      // Ensure user can only update their own streaks
      if (streak.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Update streak
      const updatedStreak = await storage.updateStreak(streakId, req.body);
      res.json(updatedStreak);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.delete("/api/streaks/:id", auth.isAuthenticated, async (req, res) => {
    try {
      const streakId = parseInt(req.params.id);
      const streak = await storage.getStreak(streakId);
      
      if (!streak) {
        return res.status(404).json({ message: "Streak not found" });
      }
      
      // Ensure user can only delete their own streaks
      if (streak.userId !== req.session.userId) {
        return res.status(403).json({ message: "Unauthorized" });
      }
      
      // Delete streak
      await storage.deleteStreak(streakId);
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Insights routes
  app.get("/api/insights/:type", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const type = req.params.type;
      const insights = await storage.getInsights(userId, type);
      res.json(insights);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  app.post("/api/insights", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      const insightData = { ...req.body, userId };
      
      // Validate
      const validatedData = insertInsightSchema.parse(insightData);
      
      // Create insight
      const insight = await storage.createInsight(validatedData);
      res.status(201).json(insight);
    } catch (error) {
      if (error instanceof z.ZodError) {
        const validationError = fromZodError(error);
        return res.status(400).json({ message: validationError.message });
      }
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Smart nudges API (based on user mood and tasks)
  app.get("/api/nudges", auth.isAuthenticated, async (req, res) => {
    try {
      const userId = req.session.userId!;
      
      // Get the user's latest mood
      const latestMood = await storage.getLatestMood(userId);
      
      // Get the user's uncompleted tasks
      const tasks = await storage.getTasks(userId);
      const uncompletedTasks = tasks.filter(task => !task.completed);
      
      // If there's no mood or no tasks, we can't generate a nudge
      if (!latestMood || uncompletedTasks.length === 0) {
        return res.json(null);
      }
      
      // Generate a simple nudge based on mood and top task
      let nudgeMessage = "";
      let nudgeAction = "";
      
      switch (latestMood.type) {
        case "focused":
          nudgeMessage = "You're in your focus zone!";
          nudgeAction = "Start Now";
          break;
        case "energized":
          nudgeMessage = "Your energy is high!";
          nudgeAction = "Let's Go";
          break;
        case "tired":
          nudgeMessage = "Need a recharge?";
          nudgeAction = "Start Break";
          break;
        case "stressed":
          nudgeMessage = "Take a moment to breathe";
          nudgeAction = "Start Small";
          break;
        case "distracted":
          nudgeMessage = "Let's regain focus";
          nudgeAction = "Begin Pomodoro";
          break;
      }
      
      // Return the nudge with top task
      res.json({
        id: Date.now(),
        type: latestMood.type === "tired" || latestMood.type === "stressed" ? "break" : "task",
        message: nudgeMessage,
        detail: `Time to work on "${uncompletedTasks[0].title}"`,
        taskId: uncompletedTasks[0].id,
        actionText: nudgeAction
      });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  // Nudge response API
  app.post("/api/nudges/response", auth.isAuthenticated, async (req, res) => {
    try {
      // In a real app, we would store this response to improve future suggestions
      // For now, we'll just acknowledge the response
      res.json({ success: true });
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Internal server error" });
    }
  });

  const httpServer = createServer(app);

  return httpServer;
}
