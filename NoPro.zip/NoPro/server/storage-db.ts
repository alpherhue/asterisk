import { 
  users, type User, type InsertUser, 
  moods, type Mood, type InsertMood,
  tasks, type Task, type InsertTask,
  events, type Event, type InsertEvent,
  streaks, type Streak, type InsertStreak,
  insights, type Insight, type InsertInsight
} from "@shared/schema";
import { IStorage } from "./storage";
import { db } from "./db";
import { eq, desc, and, gte, lte } from "drizzle-orm";
import session from "express-session";
import connectPgSimple from "connect-pg-simple";
import { Pool } from '@neondatabase/serverless';

const PostgresSessionStore = connectPgSimple(session);

export class DatabaseStorage implements IStorage {
  sessionStore: session.Store;

  constructor() {
    this.sessionStore = new PostgresSessionStore({ 
      pool: new Pool({ connectionString: process.env.DATABASE_URL }),
      createTableIfMissing: true 
    });
  }

  // User methods
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db.insert(users).values({
      ...insertUser,
      name: insertUser.name || null,
      isAdmin: insertUser.isAdmin || false,
    }).returning();
    return user;
  }

  // Mood methods
  async getMoods(userId: number): Promise<Mood[]> {
    return db.select()
      .from(moods)
      .where(eq(moods.userId, userId))
      .orderBy(desc(moods.createdAt));
  }

  async getLatestMood(userId: number): Promise<Mood | undefined> {
    const [mood] = await db.select()
      .from(moods)
      .where(eq(moods.userId, userId))
      .orderBy(desc(moods.createdAt))
      .limit(1);
    return mood || undefined;
  }

  async createMood(insertMood: InsertMood): Promise<Mood> {
    const [mood] = await db.insert(moods).values({
      ...insertMood,
      notes: insertMood.notes || null,
    }).returning();
    return mood;
  }

  // Task methods
  async getTasks(userId: number): Promise<Task[]> {
    return db.select()
      .from(tasks)
      .where(eq(tasks.userId, userId))
      .orderBy(
        desc(tasks.priority), 
        desc(tasks.createdAt)
      );
  }

  async getTask(id: number): Promise<Task | undefined> {
    const [task] = await db.select().from(tasks).where(eq(tasks.id, id));
    return task || undefined;
  }

  async createTask(insertTask: InsertTask): Promise<Task> {
    const [task] = await db.insert(tasks).values({
      ...insertTask,
      description: insertTask.description || null,
      dueDate: insertTask.dueDate || null,
      duration: insertTask.duration || null,
      completed: false,
      priority: insertTask.priority || 0,
    }).returning();
    return task;
  }

  async updateTask(id: number, updates: Partial<Task>): Promise<Task> {
    const [task] = await db
      .update(tasks)
      .set(updates)
      .where(eq(tasks.id, id))
      .returning();
    
    if (!task) {
      throw new Error(`Task with id ${id} not found`);
    }
    
    return task;
  }

  async deleteTask(id: number): Promise<boolean> {
    const result = await db
      .delete(tasks)
      .where(eq(tasks.id, id))
      .returning({ id: tasks.id });
    
    return result.length > 0;
  }

  // Event methods
  async getEvents(userId: number, date?: string): Promise<Event[]> {
    if (!date) {
      return db
        .select()
        .from(events)
        .where(eq(events.userId, userId))
        .orderBy(events.startTime);
    }
    
    const dateStart = new Date(date);
    dateStart.setHours(0, 0, 0, 0);
    
    const dateEnd = new Date(date);
    dateEnd.setHours(23, 59, 59, 999);
    
    return db
      .select()
      .from(events)
      .where(
        and(
          eq(events.userId, userId),
          gte(events.startTime, dateStart),
          lte(events.startTime, dateEnd)
        )
      )
      .orderBy(events.startTime);
  }

  async getEvent(id: number): Promise<Event | undefined> {
    const [event] = await db.select().from(events).where(eq(events.id, id));
    return event || undefined;
  }

  async createEvent(insertEvent: InsertEvent): Promise<Event> {
    const [event] = await db.insert(events).values({
      ...insertEvent,
      location: insertEvent.location || null,
      calendarId: insertEvent.calendarId || null,
      color: insertEvent.color || null,
    }).returning();
    return event;
  }

  async updateEvent(id: number, updates: Partial<Event>): Promise<Event> {
    const [event] = await db
      .update(events)
      .set(updates)
      .where(eq(events.id, id))
      .returning();
    
    if (!event) {
      throw new Error(`Event with id ${id} not found`);
    }
    
    return event;
  }

  async deleteEvent(id: number): Promise<boolean> {
    const result = await db
      .delete(events)
      .where(eq(events.id, id))
      .returning({ id: events.id });
    
    return result.length > 0;
  }

  // Streak methods
  async getStreaks(userId: number): Promise<Streak[]> {
    return db.select()
      .from(streaks)
      .where(eq(streaks.userId, userId));
  }

  async getStreak(id: number): Promise<Streak | undefined> {
    const [streak] = await db.select().from(streaks).where(eq(streaks.id, id));
    return streak || undefined;
  }

  async createStreak(insertStreak: InsertStreak): Promise<Streak> {
    const [streak] = await db.insert(streaks).values({
      ...insertStreak,
      currentStreak: 0,
      highestStreak: 0,
      dailyProgress: {},
    }).returning();
    return streak;
  }

  async updateStreak(id: number, updates: Partial<Streak>): Promise<Streak> {
    const [streak] = await db
      .update(streaks)
      .set(updates)
      .where(eq(streaks.id, id))
      .returning();
    
    if (!streak) {
      throw new Error(`Streak with id ${id} not found`);
    }
    
    return streak;
  }

  async completeStreakForToday(id: number): Promise<Streak> {
    // Get the current streak first
    const streak = await this.getStreak(id);
    if (!streak) {
      throw new Error(`Streak with id ${id} not found`);
    }
    
    const today = new Date().toISOString().split('T')[0];
    const yesterday = new Date(Date.now() - 86400000).toISOString().split('T')[0];
    
    const dailyProgress = { ...streak.dailyProgress };
    dailyProgress[today] = true;
    
    // Check if yesterday was completed to determine streak
    let currentStreak = dailyProgress[yesterday] ? streak.currentStreak + 1 : 1;
    const highestStreak = Math.max(currentStreak, streak.highestStreak);
    
    return this.updateStreak(id, { 
      dailyProgress, 
      currentStreak,
      highestStreak
    });
  }

  async deleteStreak(id: number): Promise<boolean> {
    const result = await db
      .delete(streaks)
      .where(eq(streaks.id, id))
      .returning({ id: streaks.id });
    
    return result.length > 0;
  }

  // Insight methods
  async getInsights(userId: number, type: string): Promise<Insight[]> {
    return db.select()
      .from(insights)
      .where(
        and(
          eq(insights.userId, userId),
          eq(insights.type, type)
        )
      )
      .orderBy(desc(insights.date));
  }

  async createInsight(insertInsight: InsertInsight): Promise<Insight> {
    const [insight] = await db.insert(insights).values({
      ...insertInsight,
      data: insertInsight.data || null,
      date: new Date(),
    }).returning();
    return insight;
  }
}